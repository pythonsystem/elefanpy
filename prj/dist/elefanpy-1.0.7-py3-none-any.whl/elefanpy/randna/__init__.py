from random import *
